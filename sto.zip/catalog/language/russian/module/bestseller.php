<?php
// Heading 
$_['heading_title']	= 'Хиты продаж';

// Text
$_['text_reviews']	= 'На основании %s отзывов.'; 
?>