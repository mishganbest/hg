<?php
// Heading 
$_['heading_title']    = 'Партнерский раздел';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Войти';
$_['text_logout']      = 'Выйти';
$_['text_forgotten']   = 'Забыли пароль?';
$_['text_account']     = 'Личный кабинет';
$_['text_edit']        = 'Редактировать учетную запись';
$_['text_password']    = 'Пароль';
$_['text_payment']     = 'Способ оплаты';
$_['text_tracking']    = 'Реферальный код';
$_['text_transaction'] = 'Операции';
