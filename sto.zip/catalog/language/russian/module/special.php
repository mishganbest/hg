<?php
// Heading 
$_['heading_title'] = 'Акции';

// Text
$_['text_reviews']  = 'На основании %s отзывов.'; 
?>