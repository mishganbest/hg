<?php
/***************************************************
* Module AdSense for OpenCart 1.4.x                *
*                                                  *
* Version:  0.1b                                   *
* Author:   myOpenCart.com                         *
* Email:    mail@myopencart.com                    *
* Web:      http://myopencart.com                  *
* SVN:      $Rev: 231 $                            *
***************************************************/

$_['heading_title'] = 'Реклама';
?>