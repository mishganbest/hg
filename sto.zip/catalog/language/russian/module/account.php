<?php
// Heading 
$_['heading_title']    = 'Личный кабинет';

// Text
$_['text_register']    = 'Зарегистрироваться';
$_['text_login']       = 'Войти';
$_['text_logout']      = 'Выйти';
$_['text_forgotten']   = 'Забыли пароль?';
$_['text_account']     = 'Личный кабинет';
$_['text_edit']        = 'Редактировать учетную запись';
$_['text_password']    = 'Пароль';
$_['text_wishlist']    = 'Заметки';
$_['text_order']       = 'История заказов';
$_['text_download']    = 'Файлы для скачивания';
$_['text_return']      = 'Возвраты';
$_['text_transaction'] = 'История платежей';
$_['text_newsletter']  = 'Подписки';
?>