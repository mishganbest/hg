<?php
// Heading
$_['heading_title']     = 'Сайт на обслуживании';

// Text
$_['text_maintenance']  = 'Профилактика';
$_['text_message']      = '<h1 style="text-align:center;">Магазин закрыт на профилактические работы. <br/>Пожалуйста загляните позже!</h1>';
?>