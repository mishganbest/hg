<?php
// Text
$_['text_home']      = 'Главная';
$_['text_wishlist']  = 'Заметки (%s)';
$_['text_cart']      = 'Корзина';
$_['text_items']     = '%s шт. - %s';
$_['text_search']    = 'Поиск';
$_['text_welcome']   = 'Войти в <a rel="nofollow" href="%s">личный кабинет</a> или <a rel="nofollow" href="%s">зарегистрироваться</a>.';
$_['text_logged']    = 'Вы вошли как <a href="%s">%s</a> <b>(</b> <a href="%s">Выйти</a> <b>)</b>';
$_['text_account']   = 'Личный Кабинет';
$_['text_checkout']  = 'Оформить';
$_['text_language']  = 'Язык';
$_['text_currency']  = 'Валюта';
?>