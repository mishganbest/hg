<?php
// Text
$_['text_title']       = 'Кредитная карта / Дебетовая карта (SagePay)';
$_['text_description'] = 'Items on %s Order No: %s';
?>